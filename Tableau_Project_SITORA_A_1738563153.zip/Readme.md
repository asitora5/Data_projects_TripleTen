SITORA ABDUVOSIEVA 
Data Visualization Project(TABLEAU)
Saving Superstore

This project highlights critical areas where the superstore can improve operations, reduce losses, and enhance profitability:

Focus on profitable product subcategories and regions.
Discontinue loss-making products and subcategories.
Invest in targeted advertising campaigns in Indiana (October), Rhode Island (December), and Vermont (November).
Address high return rates by improving product quality, customer service, or refining return policies.
Use insights from the relationship between profit and return rates to make strategic business decisions on a state or product level.
By acting on these insights, the superstore can increase efficiency, reduce financial risks, and tentially achieve long-term stability and growth.
 
 # Tableau Public Link #

 https://public.tableau.com/views/Sprint4ProjectUPDATED/Part1Profitslosses?:language=en-US&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link



<div class='tableauPlaceholder' id='viz1736917410964' style='position: relative'><noscript><a href='#'><img alt=' ' src='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;SP&#47;SPRINT4PROJECT_17369173639890&#47;Part1Profitslosses&#47;1_rss.png' style='border: none' /></a></noscript><object class='tableauViz'  style='display:none;'><param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F' /> <param name='embed_code_version' value='3' /> <param name='site_root' value='' /><param name='name' value='SPRINT4PROJECT_17369173639890&#47;Part1Profitslosses' /><param name='tabs' value='yes' /><param name='toolbar' value='yes' /><param name='static_image' value='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;SP&#47;SPRINT4PROJECT_17369173639890&#47;Part1Profitslosses&#47;1.png' /> <param name='animate_transition' value='yes' /><param name='display_static_image' value='yes' /><param name='display_spinner' value='yes' /><param name='display_overlay' value='yes' /><param name='display_count' value='yes' /><param name='language' value='en-US' /></object></div>                <script type='text/javascript'>                    var divElement = document.getElementById('viz1736917410964');                    var vizElement = divElement.getElementsByTagName('object')[0];                    vizElement.style.width='100%';vizElement.style.height=(divElement.offsetWidth*0.75)+'px';                    var scriptElement = document.createElement('script');                    scriptElement.src = 'https://public.tableau.com/javascripts/api/viz_v1.js';                    vizElement.parentNode.insertBefore(scriptElement, vizElement);                </script>